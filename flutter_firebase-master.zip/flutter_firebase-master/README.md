# flutter_firebase

A new Flutter application.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.io/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.io/docs/cookbook)

For help getting started with Flutter, view our 
[online documentation](https://flutter.io/docs), which offers tutorials, 
samples, guidance on mobile development, and a full API reference.
<br>
<img src="https://user-images.githubusercontent.com/24698014/50448736-e1acbc00-0948-11e9-9029-c1a80bd05a15.gif" width="280" height="550">
<img src="https://user-images.githubusercontent.com/24698014/50447459-3ea47400-0941-11e9-9310-9d50b087bcb2.png" width="280" height="550">
<img src="https://user-images.githubusercontent.com/24698014/50447463-46641880-0941-11e9-84ba-3e19d3c1ac41.png" width="280" height="550">
<img src="https://user-images.githubusercontent.com/24698014/50447468-4c59f980-0941-11e9-96b9-ae27b479fc44.png" width="280" height="550">
<img src="https://user-images.githubusercontent.com/24698014/50447470-511ead80-0941-11e9-8143-7d33d1a505d4.png" width="280" height="550">
<img src="https://user-images.githubusercontent.com/24698014/50447472-554acb00-0941-11e9-9e72-201e3a97d44f.png" width="280" height="550">
<br>
<br>
Happy learning. :+1:
If you found this project useful, then please consider giving it a :star: on Github and sharing it with your friends via social media.
### Show some :heart: and star the repo to support the project
if you like my work support me 
## Project Created & Maintained By

### divyam joshi
# Donate

> If you found this project helpful or you learned something from the source code and want to appreciate
>
> - [PayPal](https://paypal.me/divyamjoshi)
<br>

## License

```
Copyright [2018] [Divyam Joshi]

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and limitations under the License.
